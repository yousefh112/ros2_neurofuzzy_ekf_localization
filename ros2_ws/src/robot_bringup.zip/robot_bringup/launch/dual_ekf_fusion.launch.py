import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    pkg_dir = get_package_share_directory('robot_bringup')
    
    # 1. Node EKF 1 (GPS + IMU)
    ekf_gps_imu = Node(
        package='robot_localization',
        executable='ekf_node',
        name='ekf_filter_node_gps_imu',
        output='screen',
        parameters=[os.path.join(pkg_dir, 'config', 'ekf_gps_imu.yaml')],
        remappings=[('/odometry/filtered', '/odometry/filtered_1')]
    )

    # 2. Node EKF 2 (GPS + Encoders)
    ekf_gps_enc = Node(
        package='robot_localization',
        executable='ekf_node',
        name='ekf_filter_node_gps_enc',
        output='screen',
        parameters=[os.path.join(pkg_dir, 'config', 'ekf_gps_enc.yaml')],
        remappings=[('/odometry/filtered', '/odometry/filtered_2')]
    )

    # 3. Complementary Filter (Python)
    comp_filter = Node(
        package='robot_bringup',
        executable='complementary_filter', # Deve coincidere con setup.py
        name='complementary_filter_node',
        output='screen'
    )

    return LaunchDescription([
        ekf_gps_imu,
        ekf_gps_enc,
        comp_filter
    ])